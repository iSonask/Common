//
//  FirstViewModel.swift
//  Clone
//
//  Created by Akash S on 29/11/2022.
//

import Foundation


class LoginViewModel {
    weak var appCoordinator : AuthCoordinator!
    
    func goToRegister(){
        appCoordinator.goToRegisterPage()
    }
}


class User {
    let name = ""
    let id = 0
    let address = ""
    
    
}
