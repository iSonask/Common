//
//  FirstController.swift
//  Clone
//
//  Created by Akash S on 29/11/2022.
//

import UIKit
import FlexLayout

class FirstController: UIViewController {
    var viewModel : LoginViewModel!

    @IBOutlet weak var constHeightContainerView: NSLayoutConstraint!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var collection: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
//        let webView = UIWebView(frame: view.bounds)
//        view.addSubview(webView)
//
//        if let filePath = Bundle.main.path(forResource: "hack", ofType: "html") {
//          webView.loadRequest(URLRequest(url: URL(fileURLWithPath: filePath)))
//        }
        let view1 = BasicView(text: "View 1")
        let view2 = BasicView(text: "View 2")
        let view3 = BasicView(text: "View 3")
//        containerView.flex.direction(.row).define { (flex) in
//            flex.addItem(view1).height(30)
//            flex.addItem(view2).height(30).padding(1)
//            flex.addItem(view3).height(30).padding(1)
//        }
        let mainView = UIView()
        mainView.backgroundColor = .blue
        let mainView1 = UIView()
        mainView1.backgroundColor = .green
        let mainView2 = UIView()
        mainView2.backgroundColor = .gray
        let img = UIImageView()
        img.tintColor = .white
        img.image = UIImage(named: "ios-50")

        let label = UILabel()
        label.text = "hey man"
        label.textColor = .white
        label.numberOfLines = 1
        
        let img1 = UIImageView()
        img1.image = UIImage(named: "ios-50")
        img1.tintColor = .white

        let label1 = UILabel()
        label1.text = "hey mana"
        label1.textColor = .white
        label1.numberOfLines = 0
        
        let img2 = UIImageView()
        img2.image = UIImage(named: "ios-50")
        img2.tintColor = .white
        let label2 = UILabel()
        label2.text = "hey man"
        label2.textColor = .white
        label2.numberOfLines = 0
        
        mainView.flex.alignItems(.start).justifyContent(.spaceBetween).direction(.row).wrap(.noWrap).padding(10).define { (flex) in
            flex.addItem(img).right(10).size(22)
            flex.addItem(label).height(25)
        }
        
        mainView1.flex.alignItems(.start).justifyContent(.spaceBetween).direction(.row).wrap(.noWrap).padding(10).define { (flex) in
            flex.addItem(img1).right(10).size(22)
            flex.addItem(label1).height(25)
        }
        
        mainView2.flex.alignItems(.start).justifyContent(.spaceBetween).direction(.row).wrap(.noWrap).padding(10).define { (flex) in
            flex.addItem(img2).right(10).size(22)
            flex.addItem(label2).height(25)
        }
        
        containerView.flex.alignItems(.center).justifyContent(.center).direction(.row).wrap(.wrap).padding(12).define { (flex) in
            flex.addItem(mainView)
            flex.addItem(mainView1)
            flex.addItem(mainView2)
        }

        collection.dataSource = self
        collection.delegate = self
        collection.register(MyCell.self, forCellWithReuseIdentifier: "MyCell")
        
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = UICollectionViewFlowLayout.automaticSize
        layout.minimumInteritemSpacing = 10
        layout.minimumLineSpacing = 10
        collection.collectionViewLayout = layout
        
        collection.contentInsetAdjustmentBehavior = .always
        collection.reloadData()

    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        // Layout the flexbox container using PinLayout
        // NOTE: Could be also layouted by setting directly rootFlexContainer.frame
        
        
        // Then let the flexbox container layout itself
//        containerView.pin.top().bottom().left().right()
//        containerView.pin.top().left().right()

        // 2) Let the flexbox container layout itself and adjust the height
        containerView.flex.layout(mode: .adjustHeight)
        
        // 3) Adjust the scrollview contentSize
//        containerView.contentSize = containerView.frame.size

        containerView.flex.layout()
    }

    @IBAction func gotToNext(sender: UIButton) {
        if let viewModel {
            viewModel.goToRegister()
        }
//        viewModel.goToRegister()
    }
}

extension FirstController: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCell", for: indexPath) as? MyCell {
            if indexPath.row % 2 == 0 {
//                cell.firstView.isHidden = true
            } else {
//                cell.secondView.isHidden = true
            }
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.width / 2 ) - 10, height: 200)
    }
}

class BasicView: UIView {
    
    fileprivate let label = UILabel()
    
    init(text: String? = nil) {
        super.init(frame: .zero)

        backgroundColor = UIColor(red: 0.58, green: 0.78, blue: 0.95, alpha: 1.00)
        layer.borderColor = UIColor(red: 0.37, green: 0.67, blue: 0.94, alpha: 1.00).cgColor
        layer.borderWidth = 2
               
        label.text = text
        label.font = .systemFont(ofSize: 14)
        label.textColor = .white
        label.numberOfLines = 0
        label.sizeToFit()
        addSubview(label)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
            
        
    }
    
//    var sizeThatFitsExpectedArea: CGFloat = 25 * 25
//
//    override func sizeThatFits(_ size: CGSize) -> CGSize {
//        var newSize = CGSize()
//        if size.width != CGFloat.greatestFiniteMagnitude {
//            newSize.width = size.width
//            newSize.height = sizeThatFitsExpectedArea / newSize.width
//        } else if size.height != CGFloat.greatestFiniteMagnitude {
//            newSize.height = size.height
//            newSize.width = sizeThatFitsExpectedArea / newSize.height
//        } else {
//            newSize.width = 40
//            newSize.height = sizeThatFitsExpectedArea / newSize.width
//        }
//
//        return newSize
//    }
}
