//
//  MyCell.swift
//  Clone
//
//  Created by Akash S on 15/12/2022.
//

import UIKit

class MyCell: UICollectionViewCell {
    @IBOutlet weak var firstView: UIView!
    @IBOutlet weak var secondView: UIView!
    @IBOutlet weak var thirdView: UIView!
    @IBOutlet weak var fourthView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
