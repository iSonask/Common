//
//  SecondViewModel.swift
//  Clone
//
//  Created by Akash S on 29/11/2022.
//

import Foundation


class RegisterViewModel {
    
    weak var appCoordinator : AuthCoordinator!
    
    func goToLogin(){
        appCoordinator.goToLoginPage()
    }
    
}
