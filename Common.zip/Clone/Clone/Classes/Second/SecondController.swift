//
//  SecondController.swift
//  Clone
//
//  Created by Akash S on 29/11/2022.
//

import UIKit

class SecondController: UIViewController {
    var viewModel : RegisterViewModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue

    }
    
    
    @IBAction func gotBack(sender: UIButton) {
        viewModel.goToLogin()
        
    }
}
