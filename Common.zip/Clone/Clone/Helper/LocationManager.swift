//
//  LocationManager.swift
//  Clone
//
//  Created by Akash S on 28/11/2022.
//

import Foundation
import CoreLocation

// swiftlint:disable comment_spacing
// swiftlint:disable colon
// swiftlint:disable line_length
// swiftlint:disable trailing_whitespace
// swiftlint:disable opening_brace
// swiftlint:disable identifier_name
// swiftlint:disable vertical_whitespace
// swiftlint:disable force_cast

/*
 
 class ViewController: UIViewController, LocationUpdateProtocol {

     var currentLocation : CLLocation!
     
     override func viewDidLoad() {
         super.viewDidLoad()

         NSNotificationCenter.defaultCenter().addObserver(self, selector: "locationUpdateNotification:", name: kLocationDidChangeNotification, object: nil)

         let LocationMgr = UserLocationManager.SharedManager
         LocationMgr.delegate = self
         
     }
     
     // MARK: - Notifications

     func locationUpdateNotification(notification: NSNotification) {
         let userinfo = notification.userInfo
         self.currentLocation = userinfo!["location"] as! CLLocation
         print("Latitude : \(self.currentLocation.coordinate.latitude)")
         print("Longitude : \(self.currentLocation.coordinate.longitude)")

     }

     // MARK: - LocationUpdateProtocol
     
     func locationDidUpdateToLocation(location: CLLocation) {
         currentLocation = location
         print("Latitude : \(self.currentLocation.coordinate.latitude)")
         print("Longitude : \(self.currentLocation.coordinate.longitude)")
     }
     

 }

 */




protocol LocationUpdateProtocol {
    func locationDidUpdateToLocation(location : CLLocation)
}

/// Notification on update of location. UserInfo contains CLLocation for key "location"
let kLocationDidChangeNotification = "LocationDidChangeNotification"

class LocationManager: NSObject, CLLocationManagerDelegate {
    
    static let SharedManager = LocationManager()
    
    private var locationManager = CLLocationManager()
    
    var currentLocation : CLLocation?
    
    var delegate : LocationUpdateProtocol!
    
    private override init () {
        super.init()
        self.locationManager.delegate = self
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.distanceFilter = kCLLocationAccuracyHundredMeters
        locationManager.requestAlwaysAuthorization()
        self.locationManager.startUpdatingLocation()
    }
    
    // MARK: - CLLocationManagerDelegate
    
    func locationManager(manager: CLLocationManager, didUpdateToLocation newLocation: CLLocation, fromLocation oldLocation: CLLocation) {
        currentLocation = newLocation
        let userInfo : NSDictionary = ["location" : currentLocation!]

        DispatchQueue.main.async {
            self.delegate.locationDidUpdateToLocation(location: self.currentLocation!)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: kLocationDidChangeNotification), object: self, userInfo: userInfo as [NSObject : AnyObject])
        }
    }
    
}



