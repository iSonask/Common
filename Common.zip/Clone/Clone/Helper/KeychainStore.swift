//
//  KeychainStore.swift
//  Clone
//
//  Created by Akash S on 28/11/2022.
//

import Foundation
// swiftlint:disable comment_spacing
// swiftlint:disable colon
// swiftlint:disable trailing_whitespace
// swiftlint:disable opening_brace
// swiftlint:disable vertical_whitespace


import Foundation


fileprivate enum SessionKey: String {
    
    case isFirstLaunch = "isFirstLaunch"
    case deviceToken = "deviceToken"
    case loggedUserID = "loggedUserID"
    case loggedUser = "loggedUser"
    
    func set(_ value: String) {
        UserDefaults.standard.set(value, forKey: rawValue)
    }
    
    func set(_ value: Bool) {
        UserDefaults.standard.set(value, forKey: rawValue)
    }
    
    func set(_ value: Int) {
        UserDefaults.standard.set(value, forKey: rawValue)
    }
    
    func string() -> String? {
        return UserDefaults.standard.string(forKey: rawValue)
    }
    
    func bool() -> Bool {
        return UserDefaults.standard.bool(forKey: rawValue)
    }
    
    func int() -> Int {
        return UserDefaults.standard.integer(forKey: rawValue)
    }
    
}

class Session: NSObject {
    
    //This prevents others from using the default '()' initializer for this class.
    private override init(){}
    
    
    static var isFirstLaunch: Bool {
        
        get{
            let isFirstLaunch = SessionKey.isFirstLaunch
            return isFirstLaunch.bool()
        }
        
        set(value){
            let isFirstLaunch = SessionKey.isFirstLaunch
            isFirstLaunch.set(value)
        }
        
    }
    
    static var deviceToken: String {
        
        get{
            let deviceToken = SessionKey.deviceToken
            return deviceToken.string() ?? "DeviceToken"
        }
        
        set(value){
            let deviceToken = SessionKey.deviceToken
            deviceToken.set(value)
        }
        
    }
    
    static var loggedUserID: Int {
        
        get{
            let deviceToken = SessionKey.loggedUserID
            return deviceToken.int()
        }
        
        set(value){
            let deviceToken = SessionKey.loggedUserID
            deviceToken.set(value)
        }
        
    }
    
    static var isUserLoggedIn: Bool {
        return loggedUserID > 0
    }
    
    
}








/*
 
 
 struct Auth: Codable {
     let accessToken: String
     let refreshToken: String
 }


 let auth = Auth(accessToken: "dummy-access-token",
 refreshToken: "dummy-refresh-token")

let account = "domain.com"
let service = "token"

// Save `auth` to keychain
KeychainHelper.standard.save(auth, service: service, account: account)

// Read `auth` from keychain
if let result = KeychainHelper.standard.read(service: service,
                          account: account,
                             type: Auth.self) {

print(result.accessToken)   // Output: "dummy-access-token"
print(result.refreshToken)  // Output: "dummy-refresh-token"

}
 
 */





final class KeychainHelper {
    
    static let standard = KeychainHelper()
    private init() {}
    
    func save(_ data: Data, service: String = Bundle.main.description, account: String = "") {

        let query = [
            kSecValueData: data,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecClass: kSecClassGenericPassword
        ] as CFDictionary

        // Add data in query to keychain
        let status = SecItemAdd(query, nil)

        if status == errSecDuplicateItem {
            // Item already exist, thus update it.
            let query = [
                kSecAttrService: service,
                kSecAttrAccount: account,
                kSecClass: kSecClassGenericPassword,
            ] as CFDictionary

            let attributesToUpdate = [kSecValueData: data] as CFDictionary

            // Update existing item
            SecItemUpdate(query, attributesToUpdate)
        }
    }
    
    func read(service: String, account: String) -> Data? {
        
        let query = [
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecClass: kSecClassGenericPassword,
            kSecReturnData: true
        ] as CFDictionary
        
        var result: AnyObject?
        SecItemCopyMatching(query, &result)
        
        return (result as? Data)
    }
    
    func delete(service: String, account: String) {
        
        let query = [
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecClass: kSecClassGenericPassword,
            ] as CFDictionary
        
        // Delete item from keychain
        SecItemDelete(query)
    }
}

extension KeychainHelper {
    
    func save<T>(_ item: T, service: String, account: String) where T : Codable {
        
        do {
            // Encode as JSON data and save in keychain
            let data = try JSONEncoder().encode(item)
            save(data, service: service, account: account)
            
        } catch {
            assertionFailure("Fail to encode item for keychain: \(error)")
        }
    }
    
    func read<T>(service: String, account: String, type: T.Type) -> T? where T : Codable {
        
        // Read item data from keychain
        guard let data = read(service: service, account: account) else {
            return nil
        }
        
        // Decode JSON data to object
        do {
            let item = try JSONDecoder().decode(type, from: data)
            return item
        } catch {
            assertionFailure("Fail to decode item for keychain: \(error)")
            return nil
        }
    }
    
}
