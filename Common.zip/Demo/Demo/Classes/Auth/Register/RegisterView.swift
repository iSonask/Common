//
//  RegisterView.swift
//  Demo
//
//  Created by Akash S on 06/12/2022.
//

import UIKit
import CoreData
class RegisterView: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        do{
            let user = try context.fetch(User.fetchRequest()) as! [User]
            print(user.count)
        } catch {
            print("fetching error")
        }
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func hideButton(_ sender: UIButton) {
        dismiss(animated: true)
    }
}
