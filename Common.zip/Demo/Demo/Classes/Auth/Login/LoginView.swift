//
//  LoginView.swift
//  Demo
//
//  Created by Akash S on 06/12/2022.
//

import UIKit
import CoreData
import GradientLoadingBar
import Combine

extension Notification.Name {
    static let newEvent = Notification.Name("new_event")
}
 
struct Event {
    let title: String
    let scheduledOn: Date
}
 

class LoginView: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    private let notchGradientLoadingBar = NotchGradientLoadingBar(isRelativeToSafeArea: true)
    let eventPublisher = NotificationCenter.Publisher(center: .default, name: .newEvent, object: nil)

    override func viewDidLoad() {
        super.viewDidLoad()
        notchGradientLoadingBar.fadeOut()
        // Do any additional setup after loading the view.
        keyChain.set("value", forKey: .login)
        
        do{
            let user = try context.fetch(User.fetchRequest()) as! [User]
            print(user.count)
        } catch {
            print("fetching error")
        }
        
        for i in 0...100 {
            let user = User(context: context)
            user.age = Int16(i)
            user.name = "name with unique Id "
            user.email = "Email \(i + 1)"
            appDelegate.saveContext()
        }
        handleLabel()
    }
    
    func handleLabel() {
        let subscription = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
            .sink { output in
                print("finished stream with : \(output)")
            } receiveValue: { value in
                print("receive value: \(value)")
            }
        
        RunLoop.main.schedule(after: .init(Date(timeIntervalSinceNow: 5))) {
            print(" - cancel subscription")
            subscription.cancel()
        }

    }
    
    @IBAction func show(_ sender: Any) {
        notchGradientLoadingBar.fadeIn()
//        let controller = storyboard?.instantiateViewController(withIdentifier: "RegisterView") as! RegisterView
//        controller.modalPresentationStyle = .overFullScreen
//        show(controller, sender: sender)
    }
    
}
